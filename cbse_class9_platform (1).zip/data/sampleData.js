// Sample data: subjects, chapters, and quizzes
const subjects = [
  { name: "Mathematics", chapters: ["Number Systems","Polynomials","Coordinate Geometry","Linear Equations in Two Variables"] },
  { name: "Science", chapters: ["Matter in Our Surroundings","Is Matter Around Us Pure?","Atoms and Molecules"] },
  { name: "English", chapters: ["The Fun They Had","The Road Not Taken","A Letter to God"] },
  { name: "Social Studies", chapters: ["The French Revolution","The Industrial Revolution","Resources and Development"] }
];
const quizzes = [
  { title: "General Quiz", questions: [
    { q: "What is 2+2?", options:["3","4","5","6"], answer:1 },
    { q: "State of matter with fixed volume but no fixed shape?", options:["Solid","Liquid","Gas","Plasma"], answer:1 },
    { q: "Who wrote 'The Road Not Taken'?", options:["Robert Frost","William Wordsworth","Rabindranath Tagore","Khalil Gibran"], answer:0 }
  ]}
];
