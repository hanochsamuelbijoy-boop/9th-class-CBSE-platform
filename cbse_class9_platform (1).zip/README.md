# CBSE Class 9 Learning Platform (Sample)

## What this contains
- Static frontend: index.html, subjects.html, chapters.html, quiz.html, dashboard.html
- CSS in css/style.css
- Frontend JS in js/script.js (talks to /api/* endpoints)
- Sample data in data/sampleData.js
- Node server (server.js) which serves static files and provides API endpoints that use Replit DB when available.
- package.json for easy `npm install`

## To run on Replit
1. Create a new Replit Node.js project.
2. Upload the contents of this folder into the Replit workspace (or import the repo if you push to GitHub).
3. Open the Shell and run `npm install` (or let Replit install automatically from package.json).
4. Click Run (Replit will run `node server.js`). The webview will show the site and the server will use Replit Database automatically.

## To run locally (on your computer)
1. Install Node.js (v14+).
2. In the project folder run `npm install`.
3. Run `node server.js` and open http://localhost:3000 in your browser.
