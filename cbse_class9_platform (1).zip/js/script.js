// Frontend logic for static pages + API calls to server
// Renders subjects list, chapters, quiz and dashboard interactions.
// Sample data available in data/sampleData.js for offline use.
(function(){

const api = {
  getSubjects: async ()=>{
    try{
      const res = await fetch('/api/subjects');
      if(res.ok) return res.json();
    }catch(e){}
    return typeof subjects !== 'undefined' ? subjects : [];
  },
  getChapters: async (subject)=>{
    try{
      const res = await fetch('/api/chapters?subject=' + encodeURIComponent(subject));
      if(res.ok) return res.json();
    }catch(e){}
    // fallback to local data
    const s = (typeof subjects !== 'undefined') ? subjects.find(x=>x.name===subject) : null;
    return s ? s.chapters : [];
  },
  saveProgress: async (user, chapter)=>{
    try{
      const res = await fetch('/api/save', {
        method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({user, chapter})
      });
      return res.ok ? res.json() : null;
    }catch(e){ console.error(e); return null; }
  },
  getProgress: async (user)=>{
    try{
      const res = await fetch('/api/progress?user=' + encodeURIComponent(user));
      if(res.ok) return res.json();
    }catch(e){}
    return null;
  }
};

// Render subjects page
async function renderSubjects(){
  const list = document.getElementById('subjects-list');
  if(!list) return;
  const data = await api.getSubjects();
  list.innerHTML = '';
  data.forEach(s=>{
    const el = document.createElement('div');
    el.className = 'subject-card';
    el.innerHTML = `<h3>${s.name}</h3><p>Chapters: ${s.chapters.length}</p>
      <a class="btn" href="chapters.html?subject=${encodeURIComponent(s.name)}">View Chapters</a>`;
    list.appendChild(el);
  });
}

// Render chapters page
async function renderChapters(){
  const list = document.getElementById('chapters-list');
  if(!list) return;
  const params = new URLSearchParams(location.search);
  const subject = params.get('subject') || (typeof subjects!=='undefined' && subjects[0] && subjects[0].name);
  document.getElementById('subject-title').textContent = subject + ' — Chapters';
  const chapters = await api.getChapters(subject);
  list.innerHTML = '';
  chapters.forEach(ch=>{
    const el = document.createElement('div');
    el.className = 'subject-card';
    el.innerHTML = `<h4>${ch}</h4>
      <p>Short description about ${ch}.</p>
      <button class="btn mark-done" data-chapter="${ch}">Mark done</button>`;
    list.appendChild(el);
  });
  // attach mark done handlers
  document.querySelectorAll('.mark-done').forEach(btn=>{
    btn.addEventListener('click', async ()=>{
      const user = prompt('Enter your name or id to save progress:');
      if(!user) return alert('Please provide a name/id');
      const chapter = btn.dataset.chapter;
      const result = await api.saveProgress(user, `${subject}::${chapter}`);
      if(result && result.success) alert('Saved progress!');
      else alert('Could not save progress (server may be offline).');
    });
  });
}

// Quiz page
async function renderQuiz(){
  const area = document.getElementById('quiz-area');
  if(!area) return;
  // pick first subject and first chapter's quiz if available
  const data = (typeof quizzes !== 'undefined') ? quizzes : [];
  if(data.length===0){ area.innerHTML = '<div class="card">No quizzes configured yet.</div>'; return; }
  const qset = data[0].questions.slice(0,5);
  area.innerHTML = '<div class="card"><h3>'+data[0].title+'</h3><form id="quiz-form"></form></div>';
  const form = document.getElementById('quiz-form');
  qset.forEach((q,i)=>{
    const div = document.createElement('div');
    div.innerHTML = `<p><strong>Q${i+1}.</strong> ${q.q}</p>`;
    q.options.forEach((opt,j)=>{
      div.innerHTML += `<div><label><input type="radio" name="q${i}" value="${j}" /> ${opt}</label></div>`;
    });
    form.appendChild(div);
  });
  const submit = document.createElement('button');
  submit.type='button'; submit.className='btn'; submit.textContent='Submit';
  submit.addEventListener('click', ()=>{
    const answers = qset.map((q,i)=>{
      const v = form['q'+i].value; return v===""?null:parseInt(v,10);
    });
    let score=0; answers.forEach((a,i)=>{ if(a!==null && a===qset[i].answer) score++; });
    document.getElementById('quiz-result').style.display='block';
    document.getElementById('quiz-result').textContent = `Score: ${score} / ${qset.length}`;
    // optionally save score
    const user = prompt('Enter your name/id to save score (optional):');
    if(user){
      fetch('/api/saveScore',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user,score})});
    }
  });
  form.appendChild(submit);
}

// Dashboard
async function renderDashboard(){
  const loadBtn = document.getElementById('load-progress');
  if(!loadBtn) return;
  loadBtn.addEventListener('click', async ()=>{
    const user = document.getElementById('username').value.trim();
    if(!user) return alert('Enter a name/id');
    const result = await api.getProgress(user);
    const area = document.getElementById('progress-area');
    area.innerHTML = '';
    if(!result || !result.progress){ area.innerHTML = '<div class="card">No progress found.</div>'; return; }
    const card = document.createElement('div'); card.className='card';
    card.innerHTML = `<h3>Progress for ${user}</h3><p>Completed chapters:</p><ul>${result.progress.map(p=>'<li>'+p+'</li>').join('')}</ul>`;
    area.appendChild(card);
  });
}

// Auto-run renderers based on page
document.addEventListener('DOMContentLoaded', ()=>{
  renderSubjects();
  renderChapters();
  renderQuiz();
  renderDashboard();
});

})();
