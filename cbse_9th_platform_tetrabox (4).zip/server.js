const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const port = process.env.PORT || 3000;
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname)));
let db = null;
try{
  const Database = require('@replit/database');
  db = new Database();
}catch(e){
  const mem = {};
  db = { get: async(k)=> mem[k]||null, set: async(k,v)=> { mem[k]=v; return v; } };
}
function readSample(){
  try{
    const txt = fs.readFileSync(path.join(__dirname,'data','sampleData.js'),'utf8');
    const subjMatch = txt.match(/const subjects = ([\s\S]*?)];/);
    const quizMatch = txt.match(/const quizzes = ([\s\S]*?)];/);
    const subjects = subjMatch ? JSON.parse(subjMatch[1] + ']') : [];
    const quizzes = quizMatch ? JSON.parse(quizMatch[1] + ']') : [];
    return { subjects, quizzes };
  }catch(e){ return { subjects:[], quizzes:[] }; }
}
app.get('/api/subjects',(req,res)=>{ const d=readSample(); res.json(d.subjects); });
app.get('/api/chapters',(req,res)=>{ const subject=req.query.subject; const d=readSample(); const s=d.subjects.find(x=>x.name===subject); res.json(s? s.chapters:[]); });
app.post('/api/save', async (req,res)=>{ const {user, chapter}=req.body; if(!user||!chapter) return res.status(400).json({success:false,error:'user and chapter required'}); try{ const key='progress::'+user; const existing=await db.get(key)||[]; if(!existing.includes(chapter)) existing.push(chapter); await db.set(key,existing); res.json({success:true,progress:existing}); }catch(e){ res.status(500).json({success:false,error:e.message}); } });
app.get('/api/progress', async (req,res)=>{ const user=req.query.user; if(!user) return res.status(400).json({success:false,error:'user required'}); try{ const key='progress::'+user; const progress=await db.get(key)||[]; res.json({success:true,progress}); }catch(e){ res.status(500).json({success:false,error:e.message}); } });
app.post('/api/saveScore', async (req,res)=>{ const {user, score}=req.body; if(!user) return res.status(400).json({success:false,error:'user required'}); try{ const key='score::'+user; await db.set(key,{score,updated:new Date().toISOString()}); res.json({success:true}); }catch(e){ res.status(500).json({success:false,error:e.message}); } });
app.get('/api/score', async (req,res)=>{ const user=req.query.user; if(!user) return res.status(400).json({success:false,error:'user required'}); try{ const key='score::'+user; const value=await db.get(key)||null; res.json({success:true,score:value}); }catch(e){ res.status(500).json({success:false,error:e.message}); } });
app.listen(port, ()=> console.log('Server listening on', port));
