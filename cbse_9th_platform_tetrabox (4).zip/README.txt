CBSE 9th Class Learning Platform
--------------------------------
How to run (Replit):
1. Create a new Node.js Replit.
2. Upload all folder contents into the Replit workspace (or import the repo).
3. Run `npm install` if Replit doesn't auto-install.
4. Click Run. The service will start and use Replit DB automatically if available.

How to run locally:
1. Install Node.js (v14+).
2. In project folder: npm install
3. Run: node server.js
4. Open http://localhost:3000 in your browser.
