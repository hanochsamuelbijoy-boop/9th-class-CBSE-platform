const subjects = [
  { name: "Mathematics", chapters: ["Number Systems","Polynomials","Coordinate Geometry","Linear Equations in Two Variables","Introduction to Euclid's Geometry"] },
  { name: "Science", chapters: ["Matter in Our Surroundings","Is Matter Around Us Pure?","Atoms and Molecules","Structure of the Atom"] },
  { name: "English", chapters: ["The Fun They Had","The Road Not Taken","A Letter to God","Wind"] },
  { name: "Social Studies", chapters: ["The French Revolution","The Industrial Revolution","The Story of Village Palampur","Resources and Development"] },
  { name: "Hindi", chapters: ["पाठ - 1: ज्ञान","पाठ - 2: प्रकृति","पाठ - 3: समाज","व्याकरण"] }
];
const quizzes = [
  { title: "CBSE 9th Quick Quiz", questions: [
    { q: "What is 2+2?", options:["3","4","5","6"], answer:1 },
    { q: "Which state of matter has a fixed shape?", options:["Solid","Liquid","Gas","Plasma"], answer:0 },
    { q: "Who wrote 'The Road Not Taken'?", options:["Robert Frost","William Wordsworth","Rabindranath Tagore","Khalil Gibran"], answer:0 }
  ]}
];
